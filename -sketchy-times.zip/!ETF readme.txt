!EXCLAMACHINE TYPE FOUNDRY
FREEWARE FONTS LICENSE


Use --
of the output of these fonts for any purpose, any time is welcome. In fact, if you do something interesting with it, let me know, or send me a sample or some of your shwag! Please do not distribute any !Exclamachine Type Foundry font files commercially, or in physical mass media without contacting me first. Otherwise, you may only make these fonts available from a web site if it is freely accessible to everyone. These font files may not be modified without prior consent of !Exclamachine Type Foundry.
 

Fine Print --
All fonts are copyright of, and their names are Trademarks of !Exclamachine Type Foundry. Do not take internally. If ingested, immediately induce vomiting. Please don't link directly to the fonts; link to the home page. http://www.exclamachine.com. Sub-URL's are subject to change. Do Not taunt !Exclamachine fonts. Thank you, enjoy.


-Choz